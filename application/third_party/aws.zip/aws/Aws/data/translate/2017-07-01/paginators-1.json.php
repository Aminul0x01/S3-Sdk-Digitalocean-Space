<?php
// This file was auto-generated from sdk-root/src/data/translate/2017-07-01/paginators-1.json
return [ 'pagination' => [],];
